<?php
/**
 * Plugin Name: Advanced Link Injector
 * Plugin URI:  https://github.com/kumarsunil0/Advanced-Link-Injector-Wordpress-Plugin
 * Description: Automatically injects and manages post links on static pages under specific headings based on categories. Features smart sync for Title/URL changes and automatic cleanup on Trash. Designed for sites using the Classic Editor.
 * Version: 4.0
 * Author: Sunil Kumar
 * Author URI:  https://github.com/kumarsunil0/
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// 1. ADD "SETTINGS" LINK ON THE PLUGINS PAGE
add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'ali_add_action_links' );
function ali_add_action_links( $links ) {
    $settings_link = '<a href="options-general.php?page=ali-settings">' . __('Settings') . '</a>';
    array_unshift( $links, $settings_link );
    return $links;
}

// 2. SETTINGS PAGE WITH FULL INSTRUCTIONS & POSITION CONTROL
add_action('admin_menu', 'ali_create_menu');
function ali_create_menu() {
    add_options_page('Link Injector Settings', 'Link Injector', 'manage_options', 'ali-settings', 'ali_settings_page');
}

function ali_settings_page() {
    if (isset($_POST['ali_save'])) {
        update_option('ali_mappings', $_POST['mapping']);
        echo '<div class="updated"><p>Settings saved successfully!</p></div>';
    }
    $mappings = get_option('ali_mappings', array());
    $categories = get_categories(array('hide_empty' => false));
    $pages = get_pages();
    ?>
    <style>
        .ali-container { max-width: 1100px; margin-top: 20px; font-size: 14px; }
        .ali-instructions { background: #fff; border: 1px solid #ccd0d4; border-left: 4px solid #007cba; padding: 20px; margin-bottom: 25px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
        .ali-instructions h2 { margin-top: 0; color: #23282d; }
        .ali-warning-box { background: #fff8e5; border-left: 4px solid #ffb900; padding: 15px; margin: 15px 0; }
        .ali-table-card { background: #fff; border: 1px solid #ccd0d4; padding: 20px; box-shadow: 0 1px 1px rgba(0,0,0,.04); }
        .ali-input-full { width: 100%; border-radius: 4px; padding: 6px; border: 1px solid #8c8f94; }
        .ali-badge { background: #eee; padding: 2px 6px; border-radius: 3px; font-family: monospace; font-size: 12px; }
    </style>

    <div class="wrap ali-container">
        <h1>Advanced Link Injector</h1>
        
<div class="ali-instructions">
            <h2>📖 Complete Usage Manual & Features</h2>
            <p>This plugin automates the process of adding post links to static pages. Here is a summary of all active features to help you remember how it works:</p>

            <div style="background: #f0f6fb; border: 1px solid #007cba; padding: 15px; border-radius: 4px; margin: 15px 0;">
                <h4 style="margin-top:0;">🚀 Quick Start: How to Use</h4>
                <ol style="margin-bottom:0;">
                    <li><strong>Map Categories:</strong> In the table below, select a <strong>Post Category</strong> and the <strong>Target Page</strong> where links should appear.</li>
                    <li><strong>Set the Heading:</strong> Enter the exact HTML heading from your page (e.g., <code>&lt;h2&gt;Latest Updates&lt;/h2&gt;</code>). The plugin uses this to find the list.</li>
                    <li><strong>Prepare the List:</strong> Make sure your target page has a Bullet List (<code>&lt;ul&gt;</code>) started immediately after that heading.</li>
                    <li><strong>Choose Position:</strong> Select <strong>Top</strong> (newest first) or <strong>Bottom</strong> (oldest first) for the link placement.</li>
                    <li><strong>Go Live:</strong> Simply publish a new post in that category. The plugin does the rest!</li>
                </ol>
            </div>

            <p><strong>✅ Automated Synchronization:</strong><br>
            • <strong>Title & URL Updates:</strong> If you change the post title or the permalink (URL) later, the plugin detects the change and automatically updates the link on the target page.<br>
            • <strong>Category Swapping:</strong> If you move a post from Category A to Category B, the link will automatically disappear from the first heading and reappear under the new one (if both are mapped).</p>

           <p><strong>🛠️ Technical Standards:</strong><br>
            • <strong>SEO Friendly:</strong> Links are added with <code>target="_blank"</code> and <code>rel="noopener"</code> for security and performance.<br>
            • <strong>Safe Search:</strong> Handles special characters (like <code>&amp;</code>) automatically so search-and-replace never fails.<br>
            • <strong>ID Tracking (The <code>data-ali-id</code>):</strong> Each link contains a hidden <code>data-ali-id="XX"</code> attribute. <strong>Do not remove this!</strong> This ID is what allows the plugin to find and update the link even if you change the Title or URL of the post.</p>

            <p><strong>🔄 Status & Removal Logic:</strong><br>
            • <strong>Publishing:</strong> Links are added only when a post is Published.<br>
            • <strong>Trashing:</strong> Moving a post to Trash is the <strong>only</strong> way to automatically remove the link from pages.<br>
            • <strong>Drafts:</strong> Switching to "Draft" <u>will not</u> remove the link. This allows you to keep curated links active even if the post is hidden from the main blog.</p>
        </div>

        <div class="ali-table-card">
            <h3>Configure Mappings</h3>
            <form method="post">
                <table class="widefat" style="margin-bottom: 20px;">
                    <thead>
                        <tr>
                            <th style="width: 20%;">Category</th>
                            <th style="width: 20%;">Target Page</th>
                            <th style="width: 25%;">Heading (Exact HTML)</th>
                            <th style="width: 15%;">List Position</th>
                            <th style="width: 10%;">Action</th>
                        </tr>
                    </thead>
                    <tbody id="ali-mapping-rows">
                        <?php if(!empty($mappings)) {
                            foreach ($mappings as $index => $map): 
                                $pos = isset($map['pos']) ? $map['pos'] : 'top'; ?>
                            <tr>
                                <td><select name="mapping[<?php echo $index; ?>][cat]" class="ali-input-full">
                                    <?php foreach ($categories as $cat) echo "<option value='{$cat->slug}' " . selected($map['cat'], $cat->slug, false) . ">{$cat->name}</option>"; ?>
                                </select></td>
                                <td><select name="mapping[<?php echo $index; ?>][page]" class="ali-input-full">
                                    <?php foreach ($pages as $p) echo "<option value='{$p->ID}' " . selected($map['page'], $p->ID, false) . ">{$p->post_title}</option>"; ?>
                                </select></td>
                                <td><input type="text" name="mapping[<?php echo $index; ?>][heading]" value="<?php echo esc_attr($map['heading']); ?>" class="ali-input-full" placeholder="e.g. <h2>News</h2>" /></td>
                                <td><select name="mapping[<?php echo $index; ?>][pos]" class="ali-input-full">
                                    <option value="top" <?php selected($pos, 'top'); ?>>Top of List</option>
                                    <option value="bottom" <?php selected($pos, 'bottom'); ?>>Bottom of List</option>
                                </select></td>
                                <td><button type="button" class="button remove-row" style="color:#d63638;">Remove</button></td>
                            </tr>
                            <?php endforeach; 
                        } ?>
                    </tbody>
                </table>
                <p>
                    <button type="button" id="add-row" class="button button-secondary">+ Add New Mapping</button>
                    <input type="submit" name="ali_save" class="button-primary" style="float: right;" value="Save All Settings">
                </p>
                <div style="clear:both;"></div>
            </form>
        </div>
    </div>

    <script>
        document.getElementById('add-row').addEventListener('click', function() {
            var table = document.getElementById('ali-mapping-rows');
            var rowCount = table.rows.length;
            var row = table.insertRow(-1);
            row.innerHTML = '<td><select name="mapping['+rowCount+'][cat]" class="ali-input-full"><?php foreach ($categories as $cat) echo "<option value=\'{$cat->slug}\'>{$cat->name}</option>"; ?></select></td>' +
                             '<td><select name="mapping['+rowCount+'][page]" class="ali-input-full"><?php foreach ($pages as $p) echo "<option value=\'{$p->ID}\'>{$p->post_title}</option>"; ?></select></td>' +
                             '<td><input type="text" name="mapping['+rowCount+'][heading]" class="ali-input-full" /></td>' +
                             '<td><select name="mapping['+rowCount+'][pos]" class="ali-input-full"><option value="top">Top of List</option><option value="bottom">Bottom of List</option></select></td>' +
                             '<td><button type="button" class="button remove-row" style="color:#d63638;">Remove</button></td>';
        });
        document.addEventListener('click', function(e){ if(e.target.classList.contains('remove-row')){ e.target.closest('tr').remove(); } });
    </script>
    <?php
}

// 3. PAGE EDITOR HEADING GUARD
add_action('edit_form_after_title', 'ali_show_page_heading_warning');
function ali_show_page_heading_warning() {
    global $post;
    $mappings = get_option('ali_mappings', array());
    $is_target_page = false;
    foreach ($mappings as $map) {
        if (isset($map['page']) && $map['page'] == $post->ID) { 
            $is_target_page = true; 
            break; 
        }
    }
    if ($is_target_page) {
        echo '<div class="notice notice-warning inline" style="border-left-color: #d63638; background: #fff; padding: 15px; margin-top:10px; border-width: 1px 1px 1px 4px; border-style: solid; border-color: #ccd0d4 #ccd0d4 #ccd0d4 #d63638;">';
        echo '<p style="margin-bottom: 10px;"><strong>⚠️ Advanced Link Injector Guard:</strong> This page is mapped for automatic links. If you rename or change any Headings (h2, h3, etc.), you <strong>must</strong> also update the <a href="options-general.php?page=ali-settings" target="_blank">Plugin Settings</a>.</p>';
        echo '<hr style="border: 0; border-top: 1px solid #eee; margin: 10px 0;">';
        echo '<p style="font-size: 12px; color: #666;"><strong>ID Tracking (The <code>data-ali-id</code>):</strong> Each automatic link in the editor below contains a hidden <code>data-ali-id="XX"</code> attribute. <strong>Do not remove this!</strong> This ID is what allows the plugin to find and update the link even if you change the Title or URL of the post later.</p>';
        echo '</div>';
    }
}

// 4. POST EDITOR TRASH WARNING
add_action('post_submitbox_misc_actions', 'ali_publish_warning');
function ali_publish_warning() {
    global $post;
    if ($post->post_type !== 'post' || $post->post_status !== 'publish') return;
    echo '<div class="misc-pub-section" style="background: #fff8e5; border-left: 4px solid #ffb900; padding: 10px; margin: 10px 0;">';
    echo '<strong>Advanced Link Injector:</strong> Move to <strong>Trash</strong> to remove link from pages. Draft mode will <u>not</u> remove the link.';
    echo '</div>';
}

// 5. THE LOGIC ENGINE (Safe-Search & Position Control)
add_action('save_post', 'ali_handle_save', 10, 2);
add_action('wp_trash_post', 'ali_remove_link_on_trash');

function ali_handle_save($post_id, $post) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if ($post->post_type !== 'post') return;
    ali_process_all_mappings($post_id, $post->post_status);
}

function ali_process_all_mappings($post_id, $status) {
    $mappings = get_option('ali_mappings', array());
    if (empty($mappings)) return;

    $post_url = get_permalink($post_id);
    $post_title = get_the_title($post_id);
    $post_categories = wp_get_post_categories($post_id, array('fields' => 'slugs'));
    $link_pattern = '/\s*<li><a[^>]*data-ali-id="' . $post_id . '"[^>]*>.*?<\/a><\/li>/i';

    $pages_to_update = array();
    foreach ($mappings as $map) { $pages_to_update[$map['page']][] = $map; }

    foreach ($pages_to_update as $page_id => $page_mappings) {
        $page = get_post($page_id);
        if (!$page) continue;
        $content = $page->post_content;
        $original_content = $content;

        // Cleanup: Remove old version
        $content = preg_replace($link_pattern, '', $content);

        if ($status === 'publish') {
            foreach ($page_mappings as $map) {
                if (in_array($map['cat'], $post_categories)) {
                    $target_heading = $map['heading'];
                    $pos_choice = isset($map['pos']) ? $map['pos'] : 'top';
                    $heading_found = false;

                    if (strpos($content, $target_heading) !== false) {
                        $heading_found = $target_heading;
                    } else {
                        $normalized_heading = htmlspecialchars($target_heading, ENT_QUOTES);
                        if (strpos($content, $normalized_heading) !== false) $heading_found = $normalized_heading;
                    }

                    if ($heading_found) {
                        $new_item = "\n<li><a href=\"" . $post_url . "\" target=\"_blank\" rel=\"noopener\" data-ali-id=\"" . $post_id . "\">" . $post_title . "</a></li>";
                        
                        if ($pos_choice === 'top') {
                            $list_pattern = '/(' . preg_quote($heading_found, '/') . ')\s*<(ul|ol)[^>]*>/i';
                            if (preg_match($list_pattern, $content, $matches, PREG_OFFSET_CAPTURE)) {
                                $full_match = $matches[0][0]; 
                                $content = substr_replace($content, $full_match . $new_item, $matches[0][1], strlen($full_match));
                                break;
                            }
                        } else {
                            $h_pos = strpos($content, $heading_found);
                            $after_heading = substr($content, $h_pos);
                            if (preg_match('/<\/(ul|ol)>/i', $after_heading, $end_matches, PREG_OFFSET_CAPTURE)) {
                                $close_tag = $end_matches[0][0];
                                $insert_pos = $h_pos + $end_matches[0][1];
                                $content = substr_replace($content, $new_item . "\n" . $close_tag, $insert_pos, strlen($close_tag));
                                break;
                            }
                        }
                    }
                }
            }
        }
        if ($content !== $original_content) {
            global $wpdb;
            $wpdb->update($wpdb->posts, array('post_content' => $content), array('ID' => $page_id));
            clean_post_cache($page_id);
        }
    }
}

function ali_remove_link_on_trash($post_id) { ali_process_all_mappings($post_id, 'trash'); }